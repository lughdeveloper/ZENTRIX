import { cn } from "@/lib/cn";

/** Z formado por blocos (voxels). 1 = bloco; "b" = bloco em destaque azul. */
const GRID = [
  "bbbbb",
  "...b.",
  "..b..",
  ".b...",
  "bbbbb",
] as const;

const CELL = 8;
const GAP = 2;

export function LogoMark({ className, animated = false }: { className?: string; animated?: boolean }) {
  const size = 5 * CELL + 4 * GAP;
  let i = 0;
  return (
    <svg
      viewBox={`0 0 ${size} ${size}`}
      className={cn("h-10 w-10", className)}
      role="img"
      aria-label="Logotipo ZENTRIX"
    >
      {GRID.flatMap((row, y) =>
        [...row].map((c, x) => {
          if (c === ".") return null;
          const idx = i++;
          const edge = y === 0 || y === 4;
          return (
            <rect
              key={`${x}-${y}`}
              x={x * (CELL + GAP)}
              y={y * (CELL + GAP)}
              width={CELL}
              height={CELL}
              rx={1}
              fill={edge ? "var(--color-electric)" : "var(--color-ink)"}
              className={animated ? "block-in" : undefined}
              style={animated ? ({ "--i": idx } as React.CSSProperties) : undefined}
            />
          );
        })
      )}
    </svg>
  );
}

export function Logo({ className, animated = false }: { className?: string; animated?: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-3", className)}>
      <LogoMark animated={animated} />
      <span className="font-display text-2xl font-bold tracking-[0.18em] text-ink">ZENTRIX</span>
    </span>
  );
}
