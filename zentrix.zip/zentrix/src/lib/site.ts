export const site = {
  name: "ZENTRIX",
  slogan: "Seu universo Minecraft começa aqui.",
  description:
    "Addons, mods, texturas, shaders e mapas para Minecraft Java e Bedrock, com créditos e links oficiais dos criadores.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
} as const;

/** Rotas planejadas. `module` indica em que módulo cada uma passa a existir. */
export const plannedRoutes = [
  { label: "Início", href: "/", module: "02" },
  { label: "Minecraft Bedrock", href: "/bedrock", module: "03" },
  { label: "Minecraft Java", href: "/java", module: "04" },
  { label: "Servidores", href: "/servidores", module: "08" },
  { label: "Sobre nós", href: "/sobre", module: "02" },
  { label: "Minha conta", href: "/conta", module: "06" },
  { label: "Configurações", href: "/configuracoes", module: "07" },
] as const;
