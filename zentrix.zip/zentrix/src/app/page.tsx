import { Logo } from "@/components/brand/Logo";
import { plannedRoutes, site } from "@/lib/site";

const palette = [
  { name: "Void", hex: "#04060B", use: "Fundo principal", cls: "bg-void" },
  { name: "Surface", hex: "#0A0F1C", use: "Cards e painéis", cls: "bg-surface" },
  { name: "Line", hex: "#1B2740", use: "Bordas", cls: "bg-line" },
  { name: "Electric", hex: "#2F6BFF", use: "Ações e destaques", cls: "bg-electric" },
  { name: "Glow", hex: "#66B8FF", use: "Brilho e foco", cls: "bg-glow" },
  { name: "Ink", hex: "#F4F7FF", use: "Texto principal", cls: "bg-ink" },
];

/** Página provisória do Módulo 01: mostra a fundação visual. A Home real é o Módulo 02. */
export default function FoundationPage() {
  return (
    <main>
      <section className="bg-voxel border-b border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-10 px-5 py-16 sm:py-24">
          <Logo animated className="scale-110 origin-left" />
          <h1 className="max-w-3xl font-display text-4xl font-semibold leading-[1.1] sm:text-6xl">
            {site.slogan}
          </h1>
          <p className="max-w-xl text-lg text-mute">{site.description}</p>
          <p className="w-fit rounded-(--radius-block) border border-line bg-surface px-4 py-3 text-sm text-mute shadow-glow">
            Módulo 01 — fundação visual. A página inicial completa chega no Módulo 02.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16">
        <h2 className="font-display text-2xl font-semibold">Paleta</h2>
        <ul className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {palette.map((c) => (
            <li key={c.name} className="overflow-hidden rounded-(--radius-block) border border-line bg-surface">
              <div className={`${c.cls} h-20 border-b border-line`} />
              <div className="p-3">
                <p className="font-medium">{c.name}</p>
                <p className="text-sm text-mute">{c.hex}</p>
                <p className="mt-1 text-xs text-mute">{c.use}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>

      <section className="mx-auto grid max-w-6xl gap-10 px-5 pb-20 md:grid-cols-2">
        <div>
          <h2 className="font-display text-2xl font-semibold">Tipografia</h2>
          <p className="mt-6 font-display text-3xl font-semibold">Chakra Petch</p>
          <p className="mt-1 text-sm text-mute">Títulos e marca. Angular e técnica, lembra os blocos do jogo.</p>
          <p className="mt-6 text-3xl">Hanken Grotesk</p>
          <p className="mt-1 text-sm text-mute">Textos, formulários e descrições. Legível em telas pequenas.</p>
        </div>
        <div>
          <h2 className="font-display text-2xl font-semibold">Mapa de rotas</h2>
          <ul className="mt-6 divide-y divide-line rounded-(--radius-block) border border-line bg-surface">
            {plannedRoutes.map((r) => (
              <li key={r.label} className="flex items-center justify-between px-4 py-3">
                <span>{r.label}</span>
                <span className="text-sm text-mute">Módulo {r.module}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </main>
  );
}
