# ZENTRIX

Seu universo Minecraft começa aqui. Plataforma de addons, mods, texturas e shaders para Minecraft Java e Bedrock.

## Rodar localmente
```bash
cp .env.example .env.local
npm install
npm run dev        # http://localhost:3000
npm run typecheck
```

## Estrutura (Módulo 01)
```
src/app/            rotas (App Router), layout, estilos globais e tokens
src/components/     brand/ (logo) — ui/, layout/, content/ nos próximos módulos
src/lib/            site.ts (config e rotas), cn.ts (classes)
```
Próximas pastas: `src/features/{bedrock,java,downloads,auth,admin}`, `supabase/migrations`.

## Módulos
01 Fundação (este) · 02 Home · 03 Bedrock · 04 Java · 05 Downloads · 06 Contas · 07 Config/Favoritos · 08 Servers · 09 Admin · 10 Avaliações/Criadores · 11 Segurança · 12 Testes/Deploy
